import Homebody from "../components/homebody/Homebody.jsx"
export function Home () {

    return (
        <>
        <Homebody/>
        
        </>
        )
        

}