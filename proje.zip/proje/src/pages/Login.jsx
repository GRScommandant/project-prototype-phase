import Loginbody from "../components/login/login.jsx"
export function Login () {

    return (
        <>
        <Loginbody/>
        
        
        </>
        )
        

}