import Aboutusp from "../components/Aboutus/aboutus.jsx"
export function Aboutus () {
return (
<>
<Aboutusp/>

</>
)
}
export default Aboutus